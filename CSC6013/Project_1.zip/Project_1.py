class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None

    def insert(self, data):
        new_node = Node(data)
        if self.head is None:
            self.head = new_node
            return
        if data < self.head.data:
            new_node.next = self.head
            self.head = new_node
            return
        current = self.head
        while current.next and current.next.data < data:
            current = current.next
        new_node.next = current.next
        current.next = new_node

    def remove(self, data):
        if self.head is None:
            return
        if self.head.data == data:
            self.head = self.head.next
            return
        current = self.head
        while current.next:
            if current.next.data == data:
                current.next = current.next.next
                return
            current = current.next

    def display(self):
        current = self.head
        while current:
            print(current.data, end=" ===> ")
            current = current.next
        print("None")

# Read numbers from txt file
data_file = open("./data.txt", "r")
a = []
for row in data_file:
    num = int(row.strip(', \n'))
    a.append(num)

# Sort the array
a.sort()

# Create and populate the linked list
L = LinkedList()
for num in a:
    L.insert(num)

print("Initial Linked List:")
L.display()

# Ask user for a value
user_input = None
while user_input is None:
    try:
        user_input = int(input("Enter an integer value: "))
    except ValueError:
        print("Please enter an integer value.")
    except (KeyboardInterrupt, EOFError):
        print("Closing program.")
        exit() 

# Check if user_input is in the list
current = L.head
while current and current.data < user_input:
    current = current.next

if current and current.data == user_input:
    print(f"{user_input} is already in the list. Removing it.")
    L.remove(user_input)
else:
    print(f"{user_input} is not in the list. Inserting it.")
    L.insert(user_input)

print("Final Linked List:")
L.display()