import math

# Recursive function calculate the number of digits in the binary expansion/representation
def binary_recursion(n):
    """
    Using recursion, calculate the number of digits in the binary expansion/representation of n.
    
    Input:
    n: a positive integer
    
    Output:
    Returns the number of digits in the binary expansion/representation of n
    """
    # if n is 1, it has 1 digit in binary
    if n == 1:
        return 1
    #Using Recursion, add 1 more than the number of digits in n/2
    else:
        return 1 + binary_recursion(math.floor(n/2))

# Main/driver code to test the function
print(f"The number of digits in binary expansion/representation for n = 256 is: {binary_recursion(256)}")
print(f"The number of digits in binary expansion/representation for n = 750 is: {binary_recursion(750)}")