# Recursive function to calculate the sum of squares
def sum_of_squares(n):
    """
    Calculate the sum of squares of positive integers from 1 to n.
    
    Input:
    n -- a positive integer
    
    Output:
    Returns the sum of squares from 1 to n
    """
    # If n is 1, the sum is 1^2 = 1
    if n == 1:
        return 1
    # Using Recursion, it will sum the squares from 1 to n-1 plus n^2
    else:
        return sum_of_squares(n - 1) + n ** 2

# Main/driver code to test the function
print(f"The sum of the squares of the integers for n = 12 is: {sum_of_squares(12)}")
print(f"The sum of the squares of the integers for n = 20 is: {sum_of_squares(20)}")