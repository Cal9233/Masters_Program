class TreeNode:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None

class BinaryTree:
    def __init__(self):
        self.root = None
        self.child_list = []

    def insert(self, value):
        try:
            if self.root is None:
                self.root = TreeNode(value)
            else:
                self.insert_recursive(self.root, value)
        except Exception as e:
            print(f"Error inserting value {value}: {e}")

    def insert_recursive(self, current, value):
        try:
            if value < current.value:
                if current.left is None:
                    current.left = TreeNode(value)
                else:
                    self.insert_recursive(current.left, value)
            else:
                if current.right is None:
                    current.right = TreeNode(value)
                else:
                    self.insert_recursive(current.right, value)
        except Exception as e:
            print(f"Error during recursive insert of value {value}: {e}")

    def preorder(self, node):
        if node is not None:
            try:
                self.child_list.append(node.value)
                self.preorder(node.left)
                self.preorder(node.right)
            except Exception as e:
                print(f"Error during preorder traversal: {e}")

    def create_adjacency_matrix(self):
        try:
            n = len(self.child_list)
            adj_matrix = [[0] * n for _ in range(n)]

            def add_edges(node, parent_index):
                if node is None:
                    return
                try:
                    current_index = self.child_list.index(node.value)
                    if node.left:
                        left_index = self.child_list.index(node.left.value)
                        adj_matrix[parent_index][left_index] = abs(node.value - node.left.value)
                        add_edges(node.left, current_index)
                    if node.right:
                        right_index = self.child_list.index(node.right.value)
                        adj_matrix[parent_index][right_index] = abs(node.value - node.right.value)
                        add_edges(node.right, current_index)
                except ValueError as ve:
                    print(f"Error: {ve}. Node value not found in node list.")
                except Exception as e:
                    print(f"Error adding edges: {e}")

            add_edges(self.root, 0)

            return adj_matrix
        except Exception as e:
            print(f"Error creating adjacency matrix: {e}")
            return []

def fetch_file(filename):
    try:
        with open(filename, 'r') as file:
            numbers = [int(num) for num in file.read().split()]
        return numbers
    except FileNotFoundError:
        print(f"Error: The file '{filename}' was not found.")
        return []
    except ValueError as ve:
        print(f"Error: Unable to parse numbers from file '{filename}'. {ve}")
        return []
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        return []

if __name__ == "__main__":
    numbers = fetch_file('./numbers.txt')

    if numbers:
        binary_tree = BinaryTree()
        for num in numbers:
            binary_tree.insert(num)

        binary_tree.preorder(binary_tree.root)

        adj_matrix = binary_tree.create_adjacency_matrix()

        for row in adj_matrix:
            print(row)
    else:
        print("No numbers to insert into the binary tree.")
