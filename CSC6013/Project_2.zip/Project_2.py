class Person:
    def __init__(self, nickname, name, familyName, age):
        self.nickname = nickname
        self.name = name
        self.familyName = familyName
        self.age = age
    def __str__(self):
        return f"{self.name}, {self.familyName}, (Known as {self.nickname}), is {self.age} years old."

def readPeopleFile(file):
    try:
        infile = open(file, "r")
    except FileNotFoundError:
        print(f"Error: The file '{file}' was not found.")
        return []

    people = []
    for line in infile:
        info = line.split(",")
        people.append(Person(info[0], info[1], info[2], int(info[3])))
    
    infile.close()
    return people


def main():
    people = readPeopleFile('./people.csv')
    while len(people) > 0:
        print(f"\nThere are {len(people)} people in the stack.")
        try:
            count = int(input("Enter a number between 1 to 4 (to pop from stack): "))
            if count < 1 or count > 4:
                print("Please enter a valid number between 1 and 4.")
                continue

            for i in range(count):
                if len(people) > 0:
                    pop = people.pop()
                    print(f"Removed: {pop}")
                else:
                    print("The stack is empty now.")
                    break
            
            if len(people) > 0:
                top = people[-1] 
                print(f"The person remaining at the top of the stack is: {top}")
            else:
                print("The stack is empty, now exiting.")
                break

        except ValueError:
            print("Please enter an integer value.")
        except (KeyboardInterrupt, EOFError):
            print("Closing program.")
            exit() 


if __name__ == "__main__":
    main()