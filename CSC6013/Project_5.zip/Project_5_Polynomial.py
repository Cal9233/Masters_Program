def power(x, p):
    """
    Calculate the value of x raised to the power of p using a brute-force approach.

    Parameters:
    x (float): The base value.
    p (int): The exponent, a non-negative integer.

    Returns:
    float: The value of x^p.
    """
    result = 1  # Start with 1 because x^0 = 1
    for _ in range(p):
        result *= x  # Multiply x to result p times
    return result


def evaluate(A, x):
    """
    Evaluate a polynomial at a given value of x. The polynomial is represented by an array
    of coefficients, where A[k] is the coefficient of the k-th power of x.

    Parameters:
    A (list of float): The coefficients of the polynomial.
    x (float): The value at which the polynomial should be evaluated.

    Returns:
    float: The result of the polynomial evaluated at x.
    """
    result = 0
    for k in range(len(A)):
        result += A[k] * power(x, k)  # A[k] * (x^k)
    return round(result, 2)

# Asymptotic analysis
def count_multiplications(n):
    """
    Calculates the maximum number of multiplications required to evaluate a polynomial of degree n.

    This function performs an asymptotic analysis of the polynomial evaluation algorithm.
    It counts the number of multiplications needed for:
    1. Calculating powers of x (x^0, x^1, ..., x^n)
    2. Multiplying each coefficient by its corresponding power of x

    Parameters:
    n (int): The degree of the polynomial

    Returns:
    int: The total number of multiplications required
    
    The total is therefore n(n+1)/2 + n, which simplifies to (n^2 + 3n)/2.
    """
    total = 0
    for k in range(n + 1):
        total += k  # k multiplications for power(x, k)
    total += n  # n multiplications for coefficient * power(x, k)
    return total


# Alogrithm test case
A = [12.3, 40.7, -9.1, 7.7, 6.4, 0, 8.9]  # Coefficients of the polynomial
x = 5.4  # Value of x at which to evaluate the polynomial
result = evaluate(A, x)
print(f"The result of the polynomial at x = {x} is: {result}")


n = 6  # degree of the polynomial
multiplications = count_multiplications(n)
print(f"Maximum number of multiplications for a polynomial of degree {n}: {multiplications}")
print(f"Big-Oh class: O(n^2)")