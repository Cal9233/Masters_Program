def bubbleSort(arr):
    """
    Performs an enhanced bubble sort on the input array.

    This function implements the bubble sort algorithm with the following enhancements:
    1. Early exit: If no swaps occur in an iteration, the algorithm terminates early.
    2. Operation counting: Counts and reports the number of comparisons and swaps per iteration and in total.
    3. Progress tracking: Prints the partially sorted array after each iteration.

    The algorithm sorts the array in ascending order by repeatedly stepping through the list, 
    comparing adjacent elements and swapping them if they are in the wrong order. The process 
    is repeated for each element of the array until no more swaps are needed.

    Args:
    arr (list): The input array to be sorted.

    Returns:
    None: The array is sorted in-place.
    """
    total_comp = 0
    total_swap = 0

    for i in range(len(arr) - 1):
        comparisons = 0
        swaps = 0
        is_swapped = False

        for j in range(len(arr) - i - 1):
            comparisons += 1
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swaps += 1
                is_swapped = True

        total_comp += comparisons
        total_swap += swaps

        print(f"After iteration {i + 1}:")
        print(f"Array: {arr}")
        print(f"Comparisons: {comparisons}")
        print(f"Swaps: {swaps}")
        print()

        if not is_swapped:
            break

    print(f"Sorting completed.")
    print(f"Total comparisons: {total_comp}")
    print(f"Total swaps: {total_swap}")
    print()

# Algorithm test cases
A4 = [44, 63, 77, 17, 20, 99, 84, 6, 39, 52]
print("Sorting A4:")
bubbleSort(A4)

A5 = [52, 84, 6, 39, 20, 77, 17, 99, 44, 63]
print("Sorting A5:")
bubbleSort(A5)

A6 = [6, 17, 20, 39, 44, 52, 63, 77, 84, 99]
print("Sorting A6:")
bubbleSort(A6)