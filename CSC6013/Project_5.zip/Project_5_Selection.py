def selectionSort(arr):
    """
    Performs a modified selection sort on the input array.
    
    This algorithm sorts the array in ascending order by repeatedly finding the maximum
    element from the unsorted part and placing it at the end of the sorted portion.
    It differs from standard selection sort in that it builds the sorted portion
    from right to left (largest to smallest).
    
    The function also counts and prints the number of comparisons and swaps
    performed in each iteration.
    
    Args:
    arr (list): The input array to be sorted.
    
    Returns:
    None: The array is sorted in-place.
    """
    for i in range(len(arr) - 1, 0, -1):
        comparisons = 0
        maxIndex = 0
        swaps = 0
        
        for j in range(1, i + 1):
            comparisons += 1
            if arr[j] > arr[maxIndex]:
                maxIndex = j
        
        if maxIndex != i:
            arr[i], arr[maxIndex] = arr[maxIndex], arr[i]
            swaps += 1
        
        print(f"After iteration {len(arr) - i}:")
        print(f"Array: {arr}")
        print(f"Comparisons: {comparisons}")
        print(f"Swaps: {swaps}")
        print()

# Arrays for testing
A1 = [63, 44, 17, 77, 20, 6, 99, 84, 52, 39]
print("Sorting A1:")
selectionSort(A1)

A2 = [84, 52, 39, 6, 20, 17, 77, 99, 63, 44]
print("Sorting A2:")
selectionSort(A2)

A3 = [99, 84, 77, 63, 52, 44, 39, 20, 17, 6]
print("Sorting A3:")
selectionSort(A3)